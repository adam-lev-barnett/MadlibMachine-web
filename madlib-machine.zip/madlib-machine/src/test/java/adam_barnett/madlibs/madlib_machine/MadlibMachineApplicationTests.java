package adam_barnett.madlibs.madlib_machine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MadlibMachineApplicationTests {

	@Test
	void contextLoads() {
	}

}
